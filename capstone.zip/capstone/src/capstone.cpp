/******************************************************/
//       THIS IS A GENERATED FILE - DO NOT EDIT       //
/******************************************************/

#line 1 "c:/Users/Nerdom/Desktop/capstone/src/capstone.ino"
#include <google-maps-device-locator.h>
#include "Particle.h"
#include "application.h"
#include <cstdio>
#include <JsonParserGeneratorRK.h>
#include <ntp-time.h>
#include <cstring>
#include "MCP9808.h"

String hhmmss(unsigned long int now);
void timeFunction();
void bluetoothReceive();
void encoderDial();
void encoderDecision();
void externalTempFunction();
void setup();
void locationCallback(float lat, float lon, float accuracy);
void internalTemp();
void stopwatch();
void tempHandler(const char *event, const char *data);
void geoIpHandler(const char *event, const char *data);
void ipHandler(const char *event, const char *data);
void screenWrite();
void cityWrite();
void loop();
#line 10 "c:/Users/Nerdom/Desktop/capstone/src/capstone.ino"
#define UART_TX_BUF_SIZE        20

SYSTEM_THREAD(ENABLED);

Thread internalTempThread;
Thread externalTempThread;
Thread timeThread;
Thread screenWriteThread;
Thread stopWatchThread;
Thread cityWriteThread;
Thread encoderDialThread;

bool previousA3=HIGH; // Previous value (High or Low) of A3
bool previousA4=HIGH; // Previous value (High or Low) of A4
int counter = 0; // Value of encoder

MCP9808 mcp = MCP9808();
int lastResult = 0;
unsigned int nextTime = 30;    // Next time to contact the server
String global_lat = "";
String global_lon = "";
String global_city = "";
String global_regionCode = "";
String global_ip = "";
int i = 0;
float convertedTemp = 0;
String tempReceived;
JsonParserStatic<512, 50> jsonParser;
NtpTime* ntpTime;
float internalTempValue = 0;
bool wifiKeyState = false;
char ssid[64];
char passkey[64];


//bluetooth inits
void onDataReceived(const uint8_t* data, size_t len, const BlePeerDevice& peer, void* context);

const char* serviceUuid = "6E400001-B5A3-F393-E0A9-E50E24DCCA9E";
const char* rxUuid = "6E400002-B5A3-F393-E0A9-E50E24DCCA9E";
const char* txUuid = "6E400003-B5A3-F393-E0A9-E50E24DCCA9E";

BleCharacteristic txCharacteristic("tx", BleCharacteristicProperty::NOTIFY, txUuid, serviceUuid);
BleCharacteristic rxCharacteristic("rx", BleCharacteristicProperty::WRITE_WO_RSP, rxUuid, serviceUuid, onDataReceived, &rxCharacteristic);

uint8_t txBuf[UART_TX_BUF_SIZE];
size_t txLen = 0;


String hhmmss(unsigned long int now)  //format value as "hh:mm:ss"
{
  int time = 0;
  if (Time.hour(now) - 5 < 0 )
  {
    time = Time.hour(now) + 7;
  }
  String hour = String (0);
  if (Time.hour(now) > 12) {
    hour = String (Time.hour(now) - 17);
  }
  else {
    hour = String (Time.hour(now) - 5);
  }
  //String hour = String(Time.hour(now));
  String minute = String::format("%02i",Time.minute(now));
  String second = String::format("%02i",Time.second(now));
  return hour + ":" + minute;
};

void timeFunction(){
  while(1){
    static unsigned long waitMillis;
    struct epochMillis now;  //holds the unix epoch time to millisecond resolution
    char dataClock [64];
    if(millis() > waitMillis) {
        ntpTime->nowMillis(&now);  //get the current NTP time
        Particle.publish("NTP clock is: ", hhmmss(now.seconds) + "." + String::format("%03i",now.millis));
        Particle.publish("System clock is: ", hhmmss(Time.now()));
        Serial.println(hhmmss(now.seconds) + "." + String::format("%03i",now.millis));
        Serial.println("System: " + hhmmss(Time.now()));
        sprintf(dataClock, "t3.txt=\"%s\"\xFF\xFF\xFF", hhmmss(Time.now()).c_str());
        Serial1.println(dataClock);
        Serial.println(dataClock);
        waitMillis = millis() + (3000);  // wait 3 seconds
    }
  }
}

void bluetoothReceive() {
  if (BLE.connected()) {
        while (Serial.available() && txLen < UART_TX_BUF_SIZE) {
            txBuf[txLen++] = Serial.read();
            Serial.write(txBuf[txLen - 1]);
        }

        if (txLen > 0) {
            txCharacteristic.setValue(txBuf, txLen);
            txLen = 0;
        }
    }
}

void onDataReceived(const uint8_t* data, size_t len, const BlePeerDevice& peer, void* context) {
/*     LOG(TRACE, "Received data from: %02X:%02X:%02X:%02X:%02X:%02X:",
            peer.address()[0], peer.address()[1], peer.address()[2], peer.address()[3], peer.address()[4], peer.address()[5]);

    BleCharacteristic* characteristic = static_cast<BleCharacteristic*>(context);
    BleUuid uuid = characteristic->UUID();
    Serial1.print("Characteristic UUID: ");
    for (int i = 0; i < 16; i++) {
        Serial1.printf("0x%02X,", uuid.full()[i]);
    }
    Serial1.println("");*/
    WiFi.on();
    WiFi.clearCredentials();

    char buffer[10];
    if(wifiKeyState == false){
        for (uint8_t i = 0; i < len; i++) {
            ssid[i] = (char) data[i];
        }
        ssid[len] = 0x00;
        wifiKeyState = true;
        Serial.printf("Wifi SSID set to: %s\n", ssid);
    }
    else if(wifiKeyState == true){
        for (uint8_t i = 0; i < len; i++) {
            passkey[i] = (char) data[i];
        }
        passkey[len] = 0x00;
        wifiKeyState = false;
        Serial.printf("Wifi PSK set to: %s\n", passkey);
        WiFi.disconnect();
        WiFi.setCredentials(ssid, passkey, WPA2);
        WiFiAccessPoint ap[5];
        int found = WiFi.getCredentials(ap, 5);
        for (int i = 0; i < found; i++) {
          Serial.print("ssid: ");
          Serial.println(ap[i].ssid);
          // security is one of WLAN_SEC_UNSEC, WLAN_SEC_WEP, WLAN_SEC_WPA, WLAN_SEC_WPA2, WLAN_SEC_WPA_ENTERPRISE, WLAN_SEC_WPA2_ENTERPRISE
          Serial.print("security: ");
          Serial.println(ap[i].security);
          // cipher is one of WLAN_CIPHER_AES, WLAN_CIPHER_TKIP or WLAN_CIPHER_AES_TKIP
          Serial.print("cipher: ");
          Serial.println(ap[i].cipher);
        }
        Serial.println("WiFi Set");
        WiFi.connect();
    }
}
char data5 [64];
void encoderDial() {
  while(1){  
    if (digitalRead(A3) == LOW && previousA3 == HIGH){
      counter++;
      if(digitalRead(A4) == LOW && digitalRead(A3) == LOW){
        counter--;
        counter--; // Cancels out the counter++
      }
      Serial.println(counter);
    }
    previousA3 = digitalRead(A3); //Sets new "previous" variables
    previousA4 = digitalRead(A4);
    encoderDecision();
    //Serial1.print(data5);
    //Serial.print(data5);
  }
}

void encoderDecision() {
  sprintf(data5, "\"page %i\"\xFF\xFF\xFF", (int) counter);
  Serial1.print(data5);
  Serial.print(data5);
  delay(1500);
}

void externalTempFunction() {
    while(1) {
      // Step 1: get IP
      Serial.println("externalTempFunction: calling IP");
      Particle.publish("particle/device/ip");
      delay(4000);

      // Step 2: get geo location
      Serial.println("externalTempFunction: calling geoip");
      Particle.publish("geoip", global_ip.c_str(), PRIVATE);
      delay(4000);

      // Step 3: get temp
      Serial.printlnf("externalTempFunction:currentTemp is %s", tempReceived.c_str());
      //double temp = https://api.weatherbit.io/v2.0/current?city=Lombard,NC&key=c175924274b5402e8413adbee368dd35;
      char data[64];
      sprintf(data, "%s,%s", global_lat.c_str(), global_lon.c_str());//move to geoip handler so is step by step
      Particle.publish("tempRead", data, PRIVATE);//                    that way it is event driven
      Serial.println("externalTempFunction:published");
      delay(10000);
    }
}

void setup() {
    Serial.begin(9600);
    Serial1.begin(115200);
    Particle.subscribe("hook-response/tempRead", tempHandler, MY_DEVICES);
    Particle.subscribe("hook-response/geoip", geoIpHandler, MY_DEVICES);
    externalTempThread = Thread("externalTemp", externalTempFunction);
    stopWatchThread = Thread("stopWatchTask", stopwatch);
    internalTempThread = Thread("sensorTemp", internalTemp);
    cityWriteThread = Thread("cityThread", cityWrite);
    screenWriteThread = Thread("screenThread", screenWrite);
    encoderDialThread = Thread("encoderThread", encoderDial);
    timeThread = Thread("timeTask", timeFunction);
    tempReceived = "No IP";
    Particle.subscribe("particle/device/ip", ipHandler);
    WiFi.on();
    pinMode(A2, INPUT);
    /*while(! mcp.begin()) {
      Serial.println("MCP9808 not found");
      delay(500);
    }
    Serial.println("MCP9808 OK");*/
    pinMode (A3, INPUT_PULLUP);
    pinMode (A4, INPUT_PULLUP);
    BLE.addCharacteristic(txCharacteristic);
    BLE.addCharacteristic(rxCharacteristic);
    BleAdvertisingData data;
    data.appendServiceUUID(serviceUuid);
    data.appendLocalName("DYOL");
    BLE.advertise(&data);
    WiFi.setCredentials("WCL","atmega328", WPA2);
    WiFi.connect();
}

void locationCallback(float lat, float lon, float accuracy) {
}

void internalTemp(){
  Serial.println("internalTemp:called");
  while(1){
    Serial.println("internalTemp:while-entered");
    char dataInternal [64];
    convertedTemp = (analogRead(A2) * (3300.0 / 4095));
    convertedTemp = ((convertedTemp - 50)/10);
    Serial.printlnf("internalTemp:%f",convertedTemp);
    sprintf(dataInternal, "t1.txt=\"%i\"\xFF\xFF\xFF", (int) convertedTemp);
    Serial1.println(dataInternal);
    delay(10000);
    /*
    float celcius = mcp.getTemperature();
    Serial.print(celcius); Serial.println(" (C) internal");

    float fahreinheit = (celcius * (1.8)) + 32;
    Serial.print(fahreinheit); Serial.println(" (F) internal");
    
    delay(10000);*/
    /*Serial.printlnf("t1.txt=\"Internal Temp:\"\xFF\xFF\xFF");
    Serial1.printf("t1.txt=\"Internal Temp:\"\xFF\xFF\xFF");
    delay(2000);
    Serial.printlnf("t1.txt=\"%f\"\xFF\xFF\xFF", fahreinheit);
    Serial1.printf("t1.txt=\"%f\"\xFF\xFF\xFF", fahreinheit);
    delay(2000);*/
  }
}

void stopwatch() {
  Serial.println("stopwatch:called");
  int timeElapsed = 0;
  bool startedButton = false;
  bool started = false;
  char data [64];
  while(1) {
    if(startedButton == true){
      started = true;
      Serial.println("stopwatch:started");
    }
    while(started == true){
      timeElapsed=timeElapsed+1;
      Serial.print(timeElapsed);
      sprintf(data, "n0.val=\"%f\"\xFF\xFF\xFF", (timeElapsed/10));
      Serial1.printf(data);
      Serial.println(data);
      if(startedButton == true){
        started = false;
        Serial.println("stopwatch:stopped");
      }
      delay(100);
    }
  }
}

void tempHandler(const char *event, const char *data) {
  // Handle the integration response
  Serial.printlnf("tempHandler:dataReceived=%s", data);
  jsonParser.addString(data);
  if (jsonParser.parse()) {
    jsonParser.getOuterValueByKey("tempReceived", tempReceived);
    
    // Put code to do something with tempMin and tempMax here
    Serial.printlnf("tempReceived=%s", tempReceived.c_str());
  }
  jsonParser.clear();
}

void geoIpHandler(const char *event, const char *data) {
  Serial.println("geoIpHandler:called");
  Serial.println(data);

  jsonParser.addString(data);
  if (jsonParser.parse()) {
    jsonParser.getOuterValueByKey("latitude", global_lat);
    jsonParser.getOuterValueByKey("longitude", global_lon);
    jsonParser.getOuterValueByKey("city", global_city);
    jsonParser.getOuterValueByKey("region_code", global_regionCode);

    //serial debugging
    Serial.printlnf("lat=%s,lon=%s,city=%s,region_code=%s", global_lat.c_str(), global_lon.c_str(), global_city.c_str(), global_regionCode.c_str());
  }
  jsonParser.clear();
}

void ipHandler(const char *event, const char *data) {
  Serial.println("ipHandler: called");
  Serial.println(data);
  global_ip = data;
  Serial.printlnf("global_ip=%s", global_ip.c_str());
}

void screenWrite() {
  Serial.println("screenWrite:entered");
  while(1) {
    Serial.println("screenWrite:while-loop-entered");
    char data [64];
    sprintf(data, "t0.txt=\"%s\"\xFF\xFF\xFF", tempReceived.c_str());
    Serial.println(data);
    Serial1.printf(data);
    //Serial1.printf("t0.txt=\"Waiting for temp\"\xFF\xFF\xFF");
    //Serial.printlnf("t0.txt=\"Waiting for temp\"\xFF\xFF\xFF");
    delay(10000);
  }
}

void cityWrite() {
  Serial.println("cityWrite:entered");
  while(1) {
    char dataCity [64];
    sprintf(dataCity, "t2.txt=\"%s,%s\"\xFF\xFF\xFF", global_city.c_str(), global_regionCode.c_str());
    Serial.println(dataCity);
    Serial1.printf(dataCity);
    delay(10000);
  }
}

void loop(){
  /*
  Serial.println("loop:entered");
  while(1) {
    Serial.println("loop:while-loop-entered");
    char data [64];
    //sprintf(data, "t0.txt=%s", tempReceived.c_str());
    sprintf(data, "t0.txt=\"%s\"\xFF\xFF\xFF", tempReceived.c_str());
    Serial.println(data);
    //Serial1.printf("t0.txt=\"%s\"\xFF\xFF\xFF", tempReceived);
    Serial1.printf(data);
    //Serial.printlnf("t0.txt=\"%s\"\xFF\xFF\xFF", tempReceived);
    delay(5000);
    //Serial1.printf("t0.txt=\"Waiting for temp\"\xFF\xFF\xFF");
    //Serial.printlnf("t0.txt=\"Waiting for temp\"\xFF\xFF\xFF");
    //delay(1000);
  } 
  */
}